"""Independent Life World system."""
